#### SECTION 1 ####

#1.1: Get all modules loaded
from ansys.dpf import post
from ansys.dpf import core as dpf
from ansys.dpf.core import operators as coreops
from ansys.dpf.core import fields_container_factory
from ansys.dpf.core.plotter import DpfPlotter

# For the new capabilities, we need pyvista, and numpy along with os
import pyvista as pv
import numpy as np
import os

# 1.2: Specify variables for filenames and directory
#      Make sure you change this to your directory and RST file
#      Note that Python converst / to \ on windows so you don't have to. 
#rstFile = "twrtest1-str.rst"
rstFile = "housing_thermal.rth"
#rstFile = "twrtest1-thrm.rth"
#rstDir = "C:/Users/eric.miller/OneDrive - PADT/Development/pyAnsys/twrtest/"
rstDir = "C:/Users/eric.miller/OneDrive - PADT/Development/pyAnsys/housing_thermal/"
outroot= "h1"

#1.3: Now define some parameters we will need to 
#     get other result types, scale distortion, and write to more than one format

# They ansys value to retrieve. Valid result types are: 
#     ux, uy,uz, usum, seqv, s1,s2,s3,sx,sy,sz, sxy, sxz, syz, tmp
rsttype = "tmp"

# A scale factor for the max deflection value on the 
# model as a percent of the largest value of the bounding box
pcntdfl = 5
pcntdfl = 0

# The 3d result file format. For now we will check for vtk or wrl
outtype = "wrl"

# The result step/mode to grab
rstnum = 1

#1.4: Build the output file name from the file root and 
#     the result type and file type
outfname = outroot + "-" + rsttype + "-" + str(rstnum) + "." + outtype

#1.5: Let the user know what you have
print ("==========================================================================")
print ("Starting the translation of your Ansys results to a different file format")
print ("  Input file: ", rstFile)
print ("  Directory: ", rstDir)
print ("  Output file: ", outfname)
print ("  Solution step/mode: ", rstnum)
print ("  Result type: ", rsttype)
print ("  Percent deflection distortion: ", pcntdfl)
print ("-------------------------------------------------------------------------")

#### SECTION 2 ####

#2.1: Open the result file and load the solution and mesh
os.chdir(rstDir)
path = os.getcwd()
mysol = post.load_solution(rstFile)
mymesh = mysol.mesh

#2.2: Grab the results from the specified solution step, 
#     then get the request result type (thermal or displacement and stress)
print ("++ Getting result information from file")

# Displacement, stress, and thermal for the solution set number
if rsttype == "tmp":
    thrm1 = mysol.temperature(set=rstnum)
else:
    dsp1 = mysol.displacement(set=rstnum)
    str1 = mysol.stress(set=rstnum)

#2.3: Use an if statement to pull in the specific result values

# Start with displacement
if rsttype == "u":
    rstval = dsp1.vector.result_fields_container
elif rsttype == "ux":
    rstval = dsp1.x.result_fields_container
elif rsttype == "uy":
    rstval = dsp1.y.result_fields_container
elif rsttype == "uz":
    rstval = dsp1.z.result_fields_container
elif rsttype == "usum":
    rstval = dsp1.norm.result_fields_container

# Now check for stresses
elif rsttype == "seqv":
    rstval = str1.von_mises.result_fields_container
elif rsttype == "s1":
    rstval = str1.principal_1.result_fields_container
elif rsttype == "s2":
    rstval = str1.principal_2.result_fields_container
elif rsttype == "s3":
    rstval = str1.principal_3.result_fields_container
elif rsttype == "sx":
    rstval = str1.xx.result_fields_container
elif rsttype == "sy":
    rstval = str1.yy.result_fields_container
elif rsttype == "sz":
    rstval = str1.zz.result_fields_container
elif rsttype == "sxy":
    rstval = str1.xy.result_fields_container
elif rsttype == "sxz":
    rstval = str1.xz.result_fields_container
elif rsttype == "syz":
    rstval = str1.yz.result_fields_container

# Last, do temperatures
elif rsttype == "tmp":
    rstval = thrm1.scalar.result_fields_container

#### SECTION 3 #####

# 3.1: If this is thermal, just copy the 
#      undistored mesh to the variables we will us to plot and write 
if rsttype == "tmp": 
    dflmesh = mymesh.deep_copy()
    newcoord = dflmesh.nodes.coordinates_field
else:
    #3.2: Not thermal so get info needed to calculate a distorted mesh
    print("++ Calculating deflection distortion")

    # Grab the total distortion at each node
    usumval = dsp1.vector.result_fields_container

    # Get model extents. Feed the min_max operator "mymesh"
    extop = dpf.operators.min_max.min_max(mymesh.nodes.coordinates_field)
    coordmin = extop.outputs.field_min()
    coordmax = extop.outputs.field_max()
    
    # Look at the X, Y, Z min and max coordinate 
    #   value and find the biggest demention of the mesh
    #   There is probably a clever python way to do this in one line
    dltmax =0.0
    for i in range(0,3):
        if (coordmax.data[i]-coordmin.data[i]) > dltmax:
            dltmax = coordmax.data[i]-coordmin.data[i]

    # Get the maximum deflection value from usumval
    umaxop = dpf.operators.min_max.min_max(field=usumval)
    umax = 0.0
    for i in range(0,3):
        if umaxop.outputs.field_max().data[i] > umax:
                umax = umaxop.outputs.field_max().data[i]

    # Calculate a scale factor that is the specified 
    #   percentage of the max deflection devided by the max size
    dflsf = pcntdfl/100.0
    sclfact = dflsf*dltmax/umax

    #3.3: Scale the deflection values then distort the nodal coordinates 
    
    # Get a copy of the mesh to distort
    dflmesh = mymesh.deep_copy()
    newcoord = dflmesh.nodes.coordinates_field

    # Scale the deflection field by the scale factor
    sclop = dpf.operators.math.scale(usumval,float(sclfact))
    scaledusum = sclop.outputs.field()


    # Add the scaled deflection field to the nodal positions
    addop = dpf.operators.math.add(newcoord, scaledusum)
    tempcoord = addop.outputs.field()

    # Overwrite the nodal positions of dflmesh with the deflected ones
    newcoord.data = tempcoord.data

#### SECTION 4 ####
#4.1: create a Pyansys plotter object first
print ("++ Making plot (press q to exit)")
plt = DpfPlotter()

#4.2: add the result value to the deflected mesh and the plot
plt.add_field(rstval[0],dflmesh,show_edges=False)
plt.show_figure(
    show_axes=True,
    parallel_projection=False,
    background="#aaaaaa",
)

#### SECTION 5 ####

#5.1: I writing a VTK file, then do the same thing we did for the first post
#      setup a pyansys vtk_export operator, add mesh, filename, 
#      and result values, then run teh operator
print ("++ Making output file")
if outtype == "vtk":
    vtkop = coreops.serialization.vtk_export() 
    vtkop.inputs.mesh.connect(dflmesh)

    vtkop.inputs.file_path.connect(outfname)
    vtkop.inputs.fields1.connect(rstval)

    vv = vtkop.run()
    print(vv)
    print ("++ Results written to: " + outfname)

#5.2: If doing a WRL, use pyVista to create a VRML file for visualization 
#     and 3D Printing
#     The pyvista module does not work with the Ansys mesh object, 
#     so you have to do some fancy converstion to get the mesh into a 
#     grid it can use
#     It also doesn't automatically handle element values vs nodal value, 
#     so we have to handle that
elif outtype == "wrl":
    # Get the result field and the deflected mesh into some variables. 
    field = rstval[0]
    meshed_region = dflmesh

    # We are going to need the name of the field in "field" 
    # in order to grab it later
    fieldName = '_'.join(field.name.split("_")[:-1])

    # Look in the field to see if the location of the results is nodal or elemental
    if field.location == dpf.locations.nodal:
        mesh_location = meshed_region.nodes
    elif field.location == dpf.locations.elemental:
        mesh_location = meshed_region.elements
    else:
        raise ValueError(
            "Only elemental or nodal location are supported for plotting."
        )

    # Next we are going to use a mask to get a grid them assign resutls to 
    # either the element or nodal data
    overall_data = np.full(len(mesh_location), np.nan) 
    ind, mask = mesh_location.map_scoping(field.scoping)
    overall_data[ind] = field.data[mask]
    grid = meshed_region.grid
    if field.location == dpf.locations.nodal:
        grid.point_data[fieldName] = overall_data
    elif field.location == dpf.locations.elemental:
        grid.cell_data[fieldName] = overall_data

#5.3: Now that we have a grid and values on the grid, 
#     use the pyvista plotter operator to make the file
    objplt = pv.Plotter()
    objplt.add_mesh(grid) #close, data is not lined up with nodes
    objplt.export_vrml(outfname)
    print ("++ Results written to: " + outfname)

#5.4: Close out
print ("---------------------------------------------------------------------------")
print ("Done")